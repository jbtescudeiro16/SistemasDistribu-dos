public interface SalaDeEspera {


        boolean espera(String nome);
        void desiste(String nome);
        String atende();



}
