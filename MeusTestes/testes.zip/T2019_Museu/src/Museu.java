public interface Museu {
    void enterPT();
    void enterEN();
    void enterPoly();
    void enterGuide();

}
